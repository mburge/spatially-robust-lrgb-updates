#feature-id SpatiallyRobustLRGB : Spatially Robust LRGB
#feature-info Multiscale robust luminance matching and linear LRGB blending.
#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/PropertyType.jsh>
#include <pjsr/PropertyAttribute.jsh>

/*
 * Spatially Robust LRGB 0.1.4
 * Mark Burge
 *
 * Given registered, linear (not stretched), gradient-corrected, starless L and
 * RGB images, the script produces a linear LRGB blend ready for stretching and
 * a gain matched-L. By default we calculate D65 CIE Y from linear
 * sRGB/Rec.709 channels; an experimental option projects the recorded L
 * filter/QE response onto the recorded RGB filter/QE responses from PixInsight
 * processing history and adjusts for recorded SPCC channel gains. We perform
 * 32/64/128-pixel tile-median Huber IRLS fits, then if it
 * seems like a reasonable fit, we apply the median accepted slope with
 * pixel-median anchoring to create the gain matched L and then blend it with
 * the RGB. The matched-L contribution defaults to 0.65 and is selectable in
 * the dialog.
 *
 * Inputs can be selected from existing PixInsight views or opened from files.
 * The matched-L and blended-RGB products are left as new PixInsight views.
 *
 * Tile construction, marginal 1%-tail rejection, centered/scaled Huber IRLS,
 * empirical convergence guard, per-scale quality gates, multiscale slope
 * median/spread check, pixel-median final anchoring. Inputs must be externally
 * prepared starless images. FITS masks/NaNs, WCS, and arbitrary RGB primaries
 * are not handled. D65 mode assumes linear sRGB/Rec.709. The experimental
 * response projection requires RGB SPCC and L SPFC processing histories.
 */

var AstroLRGB = (function () {
   var VERSION = "0.1.4";
   var SCALES = [32, 64, 128];
   var TAIL = 0.01;
   var HUBER_K = 1.345;
   var MAX_ITERATIONS = 200;
   var STEP_TOLERANCE = 1e-8;
   var PREDICTION_TOLERANCE = 0.01;
   var PREDICTION_PATIENCE = 3;
   var MIN_TILES = 8;
   var MIN_CORRELATION = 0.85;
   var MAX_RESIDUAL_FRACTION = 0.25;
   var MAX_SLOPE_SPREAD = 0.03;
   var DEFAULT_ALPHA = 0.65;
   var Y_FLOOR = 1e-12;
   var MAX_GAIN = 10.0;
   var MAX_UNSAFE_FRACTION = 0.25;
   var SIGMA_MAD = 1.482602218505602;
   var D65_WEIGHTS = [0.2126, 0.7152, 0.0722];

   function historyProcess(view, id) {
      var matches = [];
      var histories = [view.initialProcessing, view.processing];
      for (var h = 0; h < histories.length; ++h) {
         var history = histories[h];
         if (!history) continue;
         for (var i = 0; i < history.length; ++i) {
            var instance = history.at(i);
            if (instance.processId() === id) matches.push(instance);
         }
      }
      if (matches.length !== 1)
         throw new Error(view.id + ": experimental reference requires exactly one " + id +
            " history entry; found " + matches.length + ". Save/load the original calibrated XISF if needed.");
      return matches[0];
   }

   function parseCurve(value, label) {
      if (value === null || typeof value === "undefined" || !String(value).length)
         throw new Error("Missing " + label + " response curve in processing history.");
      var words = String(value).split(","), points = [];
      if (words.length < 4 || words.length % 2)
         throw new Error("Malformed " + label + " response curve.");
      for (var i = 0; i < words.length; i += 2) {
         var wavelength = Number(words[i]), throughput = Number(words[i + 1]);
         if (!isFinite(wavelength) || !isFinite(throughput) || throughput < 0 ||
             (points.length && wavelength <= points[points.length - 1][0]))
            throw new Error("Invalid " + label + " response curve sample.");
         points.push([wavelength, throughput]);
      }
      return points;
   }

   function curveAt(points, wavelength) {
      if (wavelength < points[0][0] || wavelength > points[points.length - 1][0]) return 0;
      var lo = 0, hi = points.length - 1;
      while (hi - lo > 1) {
         var mid = (lo + hi) >> 1;
         if (points[mid][0] <= wavelength) lo = mid; else hi = mid;
      }
      var t = (wavelength - points[lo][0]) / (points[hi][0] - points[lo][0]);
      return points[lo][1] + t * (points[hi][1] - points[lo][1]);
   }

   function spccGains(view) {
      var gains = view.propertyValue("PCL:SPCC:WhiteBalanceFactors");
      if (!gains || gains.length !== 3)
         throw new Error(view.id + ": missing three SPCC white-balance factors in image properties.");
      var result = [];
      for (var i = 0; i < 3; ++i) {
         var value = Number(typeof gains.at === "function" ? gains.at(i) : gains[i]);
         if (!isFinite(value) || value <= 0)
            throw new Error(view.id + ": invalid SPCC white-balance factor for channel " + (i + 1) + ".");
         result.push(value);
      }
      return result;
   }

   function solveSmall(matrix, vector) {
      var n = vector.length, a = [], b = vector.slice();
      for (var i = 0; i < n; ++i) a.push(matrix[i].slice());
      for (var col = 0; col < n; ++col) {
         var pivot = col;
         for (var row = col + 1; row < n; ++row)
            if (Math.abs(a[row][col]) > Math.abs(a[pivot][col])) pivot = row;
         if (Math.abs(a[pivot][col]) < 1e-14) return null;
         var swap = a[col]; a[col] = a[pivot]; a[pivot] = swap;
         var value = b[col]; b[col] = b[pivot]; b[pivot] = value;
         var scale = a[col][col];
         for (var j = col; j < n; ++j) a[col][j] /= scale;
         b[col] /= scale;
         for (var r = 0; r < n; ++r) {
            if (r === col) continue;
            var factor = a[r][col];
            for (var k = col; k < n; ++k) a[r][k] -= factor * a[col][k];
            b[r] -= factor * b[col];
         }
      }
      return b;
   }

   function deriveSpccWeights(lView, rgbView) {
      var spcc = historyProcess(rgbView, "SpectrophotometricColorCalibration");
      var spfc = historyProcess(lView, "SpectrophotometricFluxCalibration");
      if (spcc.applyCalibration !== true && spcc.applyCalibration !== "true")
         throw new Error("RGB SPCC history does not record applied calibration.");
      var channels = ["red", "green", "blue"], curves = [], names = [];
      for (var c = 0; c < 3; ++c) {
         var key = channels[c] + "FilterTrCurve";
         if (String(spcc[key]) !== String(spfc[key]))
            throw new Error("RGB and L histories disagree on the " + channels[c] + " filter curve.");
         curves.push(parseCurve(spcc[key], channels[c]));
         names.push(String(spcc[channels[c] + "FilterName"]));
      }
      if (String(spcc.deviceQECurve) !== String(spfc.deviceQECurve))
         throw new Error("RGB and L histories disagree on detector QE.");
      var qe = parseCurve(spcc.deviceQECurve, "detector QE");
      var luminance = parseCurve(spfc.grayFilterTrCurve, "L filter");
      var gram = [[0,0,0],[0,0,0],[0,0,0]], rhs = [0,0,0];
      var targets = [], predictors = [];
      for (var i = 0; i <= 660; ++i) {
         var wavelength = 380 + 0.5 * i, quantumEfficiency = curveAt(qe, wavelength);
         var target = curveAt(luminance, wavelength) * quantumEfficiency;
         var predictor = [];
         for (var j = 0; j < 3; ++j)
            predictor.push(curveAt(curves[j], wavelength) * quantumEfficiency);
         targets.push(target); predictors.push(predictor);
         for (var r = 0; r < 3; ++r) {
            rhs[r] += predictor[r] * target;
            for (var col = 0; col < 3; ++col)
               gram[r][col] += predictor[r] * predictor[col];
         }
      }
      var best = null, bestError = Infinity;
      for (var mask = 1; mask < 8; ++mask) {
         var active = [];
         for (var index = 0; index < 3; ++index)
            if (mask & (1 << index)) active.push(index);
         var submatrix = [], subvector = [];
         for (var a = 0; a < active.length; ++a) {
            subvector.push(rhs[active[a]]);
            var rowValues = [];
            for (var b = 0; b < active.length; ++b)
               rowValues.push(gram[active[a]][active[b]]);
            submatrix.push(rowValues);
         }
         var solution = solveSmall(submatrix, subvector);
         if (!solution) continue;
         var coefficients = [0,0,0], feasible = true;
         for (var s = 0; s < active.length; ++s) {
            if (solution[s] < -1e-12) feasible = false;
            coefficients[active[s]] = Math.max(0, solution[s]);
         }
         if (!feasible) continue;
         var error = 0;
         for (var n = 0; n < targets.length; ++n) {
            var difference = -targets[n];
            for (var x = 0; x < 3; ++x) difference += predictors[n][x] * coefficients[x];
            error += difference * difference;
         }
         if (error < bestError) { best = coefficients; bestError = error; }
      }
      if (!best) throw new Error("Could not derive nonnegative RGB response weights.");
      var total = best[0] + best[1] + best[2];
      if (!(total > 0)) throw new Error("Derived RGB response weights are zero.");
      var rawWeights = [best[0]/total, best[1]/total, best[2]/total];
      // Assumes SPCC applies these factors as per-channel multipliers. The
      // affine L fit absorbs a common offset, but this is not a full inverse
      // of SPCC's optional background neutralization.
      var gains = spccGains(rgbView), corrected = [], correctedTotal = 0;
      for (var g = 0; g < 3; ++g) {
         corrected[g] = rawWeights[g] / gains[g];
         correctedTotal += corrected[g];
      }
      var weights = corrected.map(function (value) { return value / correctedTotal; });
      var targetEnergy = 0;
      for (var t = 0; t < targets.length; ++t) targetEnergy += targets[t] * targets[t];
      return {weights:weights, rawWeights:rawWeights, spccGains:gains,
              mode:"SPCC gain-adjusted filter/QE response projection (experimental)",
              relativeSpectralRms:Math.sqrt(bestError / targetEnergy),
              rgbFilters:names, lFilter:String(spfc.grayFilterName),
              qe:String(spcc.deviceQECurveName)};
   }

   function sortedCopy(a) {
      var b = a.slice();
      b.sort(function (x, y) { return x - y; });
      return b;
   }

   function quantile(a, p) {
      var b = sortedCopy(a);
      if (!b.length) throw new Error("Cannot calculate a quantile of an empty array");
      var h = (b.length - 1) * p;
      var lo = Math.floor(h), hi = Math.ceil(h);
      return b[lo] + (h - lo) * (b[hi] - b[lo]);
   }

   function median(a) {
      return quantile(a, 0.5);
   }

   function madSigma(a) {
      var m = median(a), d = [];
      for (var i = 0; i < a.length; ++i) d.push(Math.abs(a[i] - m));
      return SIGMA_MAD * median(d);
   }

   function predictionProgress(steps, leverage, residualSigma) {
      if (steps.length < 6 || residualSigma <= 1e-12) return null;
      var recent = steps.slice(steps.length - 6);
      var allPositive = true, allNegative = true, q = 0;
      for (var i = 0; i < recent.length; ++i) {
         allPositive = allPositive && recent[i] > 0;
         allNegative = allNegative && recent[i] < 0;
      }
      if (!allPositive && !allNegative) return null;
      for (var j = 1; j < recent.length; ++j) {
         var ratio = Math.abs(recent[j] / recent[j - 1]);
         if (!isFinite(ratio)) return null;
         q = Math.max(q, ratio);
      }
      if (!(q > 0 && q < 1)) return null;
      var remaining = Math.abs(recent[recent.length - 1]) * q / (1 - q);
      return {
         q: q,
         p95: remaining * leverage[0] / residualSigma,
         max: remaining * leverage[1] / residualSigma
      };
   }

   function fitScale(allX, allY, size, total) {
      var out = {scale:size, totalTiles:total, coveredTiles:allX.length,
                 usedTiles:0, tailRejected:0, valid:false};
      if (allX.length < MIN_TILES) {
         out.problem = "too few covered tiles";
         return out;
      }
      var lx = quantile(allX, TAIL), hx = quantile(allX, 1 - TAIL);
      var ly = quantile(allY, TAIL), hy = quantile(allY, 1 - TAIL);
      var x = [], y = [];
      for (var i = 0; i < allX.length; ++i) {
         if (allX[i] >= lx && allX[i] <= hx && allY[i] >= ly && allY[i] <= hy) {
            x.push(allX[i]); y.push(allY[i]);
         }
      }
      out.usedTiles = x.length;
      out.tailRejected = allX.length - x.length;
      if (x.length < MIN_TILES) {
         out.problem = "too few tiles after 1% marginal-tail rejection";
         return out;
      }

      var mx = median(x), my = median(y);
      var xr = quantile(x, 0.95) - quantile(x, 0.05);
      var yr = quantile(y, 0.95) - quantile(y, 0.05);
      if (!(xr > 1e-6 * Math.max(Math.abs(mx), 2.2250738585072014e-308)) ||
          !(yr > 1e-6 * Math.max(Math.abs(my), 2.2250738585072014e-308))) {
         out.problem = "insufficient dynamic range";
         return out;
      }
      var u = [], v = [], absU = [], den = 0, num = 0;
      for (var k = 0; k < x.length; ++k) {
         u[k] = (x[k] - mx) / xr;
         v[k] = (y[k] - my) / yr;
         den += u[k] * u[k];
         num += u[k] * v[k];
         absU[k] = Math.abs(u[k]);
      }
      if (!(den > 2.220446049250313e-16) || !isFinite(den)) {
         out.problem = "numerically degenerate fit";
         return out;
      }
      var initial = (num / den) * yr / xr;
      var beta = num / den;
      var steps = [], stableCount = 0, converged = false;
      var reason = "iteration_limit", iteration = 0;
      var maxAbsU = 0;
      for (var la = 0; la < absU.length; ++la) maxAbsU = Math.max(maxAbsU, absU[la]);
      var leverage = [quantile(absU, 0.95), maxAbsU];
      for (iteration = 1; iteration <= MAX_ITERATIONS; ++iteration) {
         var residual = [], sigma, weights = [], wden = 0, wnum = 0;
         for (var q = 0; q < u.length; ++q) residual[q] = v[q] - beta * u[q];
         sigma = Math.max(madSigma(residual), 1e-12);
         for (var w = 0; w < u.length; ++w) {
            var weight = Math.min(1, HUBER_K * sigma / Math.max(Math.abs(residual[w]), 2.2250738585072014e-308));
            weights[w] = weight;
            wden += weight * u[w] * u[w];
            wnum += weight * u[w] * v[w];
         }
         if (!(wden > 2.220446049250313e-16)) {
            out.problem = "degenerate weighted fit";
            return out;
         }
         var next = wnum / wden;
         var step = next - beta;
         steps.push(step);
         var nextResidual = [];
         for (var r = 0; r < u.length; ++r) nextResidual[r] = v[r] - next * u[r];
         var newSigma = madSigma(nextResidual);
         var progress = predictionProgress(steps, leverage, newSigma);
         var relativeStep = Math.abs(step) / Math.max(Math.abs(beta), 1e-12);
         var predictedStable = progress !== null &&
            progress.p95 <= PREDICTION_TOLERANCE && progress.max <= PREDICTION_TOLERANCE;
         stableCount = predictedStable ? stableCount + 1 : 0;
         beta = next;
         if (relativeStep <= STEP_TOLERANCE) {
            converged = true; reason = "slope_tolerance"; break;
         }
         if (stableCount >= PREDICTION_PATIENCE) {
            converged = true; reason = "prediction_stability"; break;
         }
      }
      iteration = Math.min(iteration, MAX_ITERATIONS);
      var slope = beta * yr / xr;
      var intercept = my - slope * mx;
      var sq = 0, resids = [], sumU = 0, sumV = 0;
      for (var z = 0; z < x.length; ++z) {
         var rr = y[z] - (my + slope * (x[z] - mx));
         resids.push(rr); sq += rr * rr;
         sumU += u[z]; sumV += v[z];
      }
      var meanU = sumU / u.length, meanV = sumV / v.length;
      var cov = 0, varU = 0, varV = 0;
      for (var c = 0; c < u.length; ++c) {
         var du = u[c] - meanU, dv = v[c] - meanV;
         cov += du * dv; varU += du * du; varV += dv * dv;
      }
      var corr = cov / Math.sqrt(varU * varV);
      var rms = Math.sqrt(sq / resids.length);
      out.slope = slope;
      out.intercept = intercept;
      out.medianL = mx;
      out.medianY = my;
      out.initialSlope = initial;
      out.residualRms = rms;
      out.residualMadSigma = madSigma(resids);
      out.pearsonR = corr;
      out.yRange90 = yr;
      out.residualFraction = rms / yr;
      out.iterations = iteration;
      out.converged = converged;
      out.convergenceReason = reason;
      out.finalX = x;
      out.finalY = y;
      var problems = [];
      if (!(isFinite(slope) && slope > 0)) problems.push("nonpositive/nonfinite slope");
      if (!converged) problems.push("IRLS did not converge");
      if (!(isFinite(corr) && corr >= MIN_CORRELATION)) problems.push("low correlation");
      if (!(isFinite(rms) && rms / yr <= MAX_RESIDUAL_FRACTION)) problems.push("excessive residuals");
      out.valid = problems.length === 0;
      out.problem = problems.join(", ");
      return out;
   }

   function fitImagePair(lImage, yImage) {
      var xSize = lImage.width, ySize = lImage.height;
      if (xSize !== yImage.width || ySize !== yImage.height)
         throw new Error("L and calculated Y dimensions must match exactly");
      console.writeln("Calculating tile medians for " + xSize + " x " + ySize + " registered pixels.");
      var scaleResults = [];
      for (var s = 0; s < SCALES.length; ++s) {
         var size = SCALES[s];
         var rows = Math.floor(ySize / size), cols = Math.floor(xSize / size);
         var total = rows * cols, xs = [], ys = [];
         console.writeln("  " + size + " px: " + total + " full tiles");
         for (var row = 0; row < rows; ++row) {
            // Anchor the full-tile grid at PixInsight image coordinate (0, 0).
            var y0 = row * size, y1 = y0 + size;
            for (var col = 0; col < cols; ++col) {
               var x0 = col * size, x1 = x0 + size;
               var tile = new Rect(x0, y0, x1, y1);
               var lx = lImage.median(tile);
               var yy = yImage.median(tile);
               if (!isFinite(lx) || !isFinite(yy))
                  throw new Error("Nonfinite tile median at scale " + size + " px; invalid pixels are unsupported.");
               xs.push(lx); ys.push(yy);
            }
            if ((row + 1) % 24 === 0 || row + 1 === rows)
               console.writeln("    rows " + (row + 1) + "/" + rows);
         }
         var result = fitScale(xs, ys, size, total);
         scaleResults.push(result);
         console.writeln(formatScale(result));
      }
      var accepted = [];
      for (var a = 0; a < scaleResults.length; ++a)
         if (scaleResults[a].valid) accepted.push(scaleResults[a]);
      if (accepted.length < 2)
         throw new Error("Need at least two valid scales; inspect per-scale diagnostics above. " +
            "Confirm L and RGB are actually the same DSO, spatially registered, and at matching " +
            "preprocessing stages (both starless and gradient corrected). RGB is assumed " +
            "linear sRGB/Rec.709. A FITS orientation/ROWORDER mismatch is also possible " +
            "if you generated one in say Siril and the other in PI WBPP.");
      var slopes = [];
      for (var b = 0; b < accepted.length; ++b) slopes.push(accepted[b].slope);
      var slope = median(slopes);
      var spread = (Math.max.apply(null, slopes) - Math.min.apply(null, slopes)) / slope;
      if (spread > MAX_SLOPE_SPREAD)
         throw new Error("Accepted-scale slope spread " + (100 * spread).toFixed(3) + "% exceeds 3%.");
      var medianL = lImage.median(), medianY = yImage.median();
      if (!isFinite(medianL) || !isFinite(medianY))
         throw new Error("Nonfinite image median; invalid pixels are unsupported.");
      var intercept = medianY - slope * medianL;
      for (var f = 0; f < accepted.length; ++f) {
         var fit = accepted[f], ss = 0;
         for (var n = 0; n < fit.finalX.length; ++n) {
            var res = fit.finalY[n] - (medianY + slope * (fit.finalX[n] - medianL));
            ss += res * res;
         }
         fit.finalModelResidualFraction = Math.sqrt(ss / fit.finalX.length) / fit.yRange90;
         if (fit.finalModelResidualFraction > MAX_RESIDUAL_FRACTION)
            throw new Error("Final pixel-median anchor exceeds the residual limit at " + fit.scale + " px.");
      }
      return {slope:slope, intercept:intercept, medianL:medianL, medianY:medianY,
              spread:spread, scales:scaleResults};
   }

   function formatScale(r) {
      if (!r.valid)
         return "  " + r.scale + " px: REJECTED; covered=" + r.coveredTiles +
            ", retained=" + r.usedTiles +
            (typeof r.slope === "undefined" ? "" :
             ", slope=" + r.slope.toPrecision(12) +
             ", intercept=" + r.intercept.toPrecision(12) +
             ", r=" + r.pearsonR.toFixed(6) +
             ", residual fraction=" + r.residualFraction.toFixed(6) +
             ", IRLS=" + r.iterations + " (" +
                (r.converged ? "converged" : "not converged") + "; " + r.convergenceReason + ")") +
            ", reason=" + r.problem;
      return "  " + r.scale + " px: slope=" + r.slope.toPrecision(12) +
         ", intercept=" + r.intercept.toPrecision(12) +
         ", retained=" + r.usedTiles + "/" + r.coveredTiles +
         ", r=" + r.pearsonR.toFixed(6) +
         ", residual MAD-sigma=" + r.residualMadSigma.toExponential(5) +
         ", IRLS=" + r.iterations + " (" + r.convergenceReason + ")";
   }

   function uniqueId(prefix) {
      var id = prefix, n = 1;
      while (!View.viewById(id).isNull) id = prefix + "_" + n++;
      return id;
   }

   function openCopy(path, idPrefix) {
      var ws = ImageWindow.open(path, uniqueId(idPrefix), "", true);
      if (!ws || ws.length !== 1) throw new Error("Could not open one image from: " + path);
      ws[0].mainView.image.rangeClippingEnabled = false;
      return ws[0];
   }

   function createPixelMathImage(targetWindow, expression, idPrefix, gray) {
      var id = uniqueId(idPrefix);
      var p = new PixelMath;
      p.expression = expression;
      p.useSingleExpression = true;
      p.createNewImage = true;
      p.showNewImage = true;
      p.newImageId = id;
      p.newImageColorSpace = gray ? PixelMath.prototype.Gray : PixelMath.prototype.SameAsTarget;
      p.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
      p.use64BitWorkingImage = true;
      p.rescale = false;
      p.truncate = false;
      if (!p.executeOn(targetWindow.mainView, false))
         throw new Error("PixelMath failed for " + idPrefix);
      var v = View.viewById(id);
      if (v.isNull) throw new Error("PixelMath did not create expected output: " + id);
      v.window.mainView.image.rangeClippingEnabled = false;
      return v.window;
   }

   function run(config) {
      var owned = [], keep = [];
      try {
         var alpha = typeof config.alpha === "number" ? config.alpha : DEFAULT_ALPHA;
         if (!isFinite(alpha) || alpha < 0 || alpha > 1)
            throw new Error("Matched-L contribution must be between 0 and 1.");
         var l = config.lView ? config.lView.window : openCopy(config.lPath, "astro_lrgb_L");
         if (!config.lView) owned.push(l);
         var rgb = config.rgbView ? config.rgbView.window : openCopy(config.rgbPath, "astro_lrgb_RGB");
         if (!config.rgbView) owned.push(rgb);
         if (l.mainView.image.isColor)
            throw new Error("L input must be a single-channel grayscale image.");
         if (!rgb.mainView.image.isColor || rgb.mainView.image.numberOfNominalChannels !== 3 ||
             rgb.mainView.image.numberOfChannels !== 3)
            throw new Error("RGB input must have exactly three color channels and no alpha channel.");
         if (l.mainView.image.width !== rgb.mainView.image.width ||
             l.mainView.image.height !== rgb.mainView.image.height)
            throw new Error("L and RGB dimensions differ; register/crop them before running.");
         if (!l.isFloatSample || !rgb.isFloatSample)
            throw new Error("L and RGB must both be 32- or 64-bit floating-point images. Convert integer inputs in PixInsight before running.");

         var referenceMode = config.referenceMode || "D65";
         if (referenceMode !== "D65" && referenceMode !== "SPCC")
            throw new Error("Unknown RGB reference mode: " + referenceMode);
         var reference = referenceMode === "SPCC" ?
            deriveSpccWeights(l.mainView, rgb.mainView) :
            {weights:D65_WEIGHTS, mode:"linear D65 CIE Y"};
         var coefficients = reference.weights;
         console.writeln("RGB reference: " + reference.mode + ".");
         console.writeln("R/G/B weights: " + coefficients.map(function (value) {
            return value.toPrecision(12);
         }).join(", "));
         if (referenceMode === "SPCC") {
            console.writeln("SPCC R/G/B white-balance factors: " + reference.spccGains.map(function (value) {
               return value.toPrecision(12);
            }).join(", ") + " (assumed applied channel multipliers).");
            console.writeln("Unadjusted response weights: " + reference.rawWeights.map(function (value) {
               return value.toPrecision(12);
            }).join(", "));
            console.writeln("Filters: L=" + reference.lFilter + "; RGB=" + reference.rgbFilters.join(" / ") +
               "; QE=" + reference.qe);
            console.writeln("Spectral response RMS fraction: " + reference.relativeSpectralRms.toFixed(6));
         }
         var rgbId = rgb.mainView.id;
         var y = createPixelMathImage(rgb,
            coefficients[0].toPrecision(17) + "*" + rgbId + "[0] + " +
            coefficients[1].toPrecision(17) + "*" + rgbId + "[1] + " +
            coefficients[2].toPrecision(17) + "*" + rgbId + "[2]",
            "astro_lrgb_Y", true);
         owned.push(y);
         var model = fitImagePair(l.mainView.image, y.mainView.image);
         console.writeln("Final model: matchedL = " + model.medianY.toPrecision(12) +
            " + " + model.slope.toPrecision(12) + " * (L - " +
            model.medianL.toPrecision(12) + ")");
         console.writeln("Equivalent affine equation: matchedL = " +
            model.slope.toPrecision(12) + " * L + " + model.intercept.toPrecision(12));
         console.writeln("Accepted-scale slope spread: " + (100 * model.spread).toFixed(4) + "%");

         var matched = createPixelMathImage(l,
            model.medianY.toPrecision(17) + " + " + model.slope.toPrecision(17) +
               "*($T-" + model.medianL.toPrecision(17) + ")",
            "astro_lrgb_matchedL", true);
         owned.push(matched);

         var yId = y.mainView.id, mId = matched.mainView.id;
         var targetExpr = (1 - alpha) + "*" + yId + " + " + alpha + "*" + mId;
         var unsafeExpr = "iif(" + yId + " <= " + Y_FLOOR + ",1,iif(" +
            targetExpr + " < 0,1,iif((" + targetExpr + ")/max(" + yId + "," +
            Y_FLOOR + ") > " + MAX_GAIN + ",1,0)))";
         var unsafe = createPixelMathImage(y, unsafeExpr, "astro_lrgb_unsafe", true);
         owned.push(unsafe);
         var unsafeFraction = unsafe.mainView.image.mean();
         console.writeln("Blend unsafe-pixel fraction: " + (100 * unsafeFraction).toFixed(4) + "%");
         if (unsafeFraction > MAX_UNSAFE_FRACTION)
            throw new Error("Unsafe blend fraction exceeds the 25% limit; no RGB output was created.");

         var ratio = "(" + targetExpr + ")/max(" + yId + "," + Y_FLOOR + ")";
         var safeGain = "iif(" + yId + " > " + Y_FLOOR + " && (" + targetExpr +
            ") >= 0 && " + ratio + " <= " + MAX_GAIN + "," + ratio + ",1)";
         var blend = createPixelMathImage(rgb, "$T*" + safeGain,
            "astro_lrgb_blend", false);
         owned.push(blend);

         var record = JSON.stringify({version:VERSION, lView:l.mainView.id,
            rgbView:rgb.mainView.id, slope:model.slope, intercept:model.intercept,
            medianL:model.medianL, medianY:model.medianY, alpha:alpha,
            referenceMode:referenceMode, referenceName:reference.mode,
            referenceWeights:coefficients,
            spccWhiteBalanceFactors:referenceMode === "SPCC" ? reference.spccGains : null,
            unadjustedResponseWeights:referenceMode === "SPCC" ? reference.rawWeights : null,
            referenceFilters:referenceMode === "SPCC" ?
               {l:reference.lFilter, rgb:reference.rgbFilters, qe:reference.qe} : null,
            relativeSpectralRms:referenceMode === "SPCC" ? reference.relativeSpectralRms : null,
            slopeSpread:model.spread, scales:model.scales.map(function (s) {
               return {scale:s.scale, valid:s.valid, slope:s.slope,
                  intercept:s.intercept, retained:s.usedTiles, correlation:s.pearsonR,
                  residualMadSigma:s.residualMadSigma};
            })});
         matched.mainView.setPropertyValue("AstroLRGB:Run", record,
            PropertyType_Auto, PropertyAttribute_Storable | PropertyAttribute_Permanent);
         blend.mainView.setPropertyValue("AstroLRGB:Run", record,
            PropertyType_Auto, PropertyAttribute_Storable | PropertyAttribute_Permanent);
         keep.push(matched, blend);
         console.writeln("Created matched L view: " + matched.mainView.id);
         console.writeln("Created blended RGB view: " + blend.mainView.id);
         console.writeln("Matched-L contribution: " + alpha.toFixed(3));
         console.writeln("Completed. Outputs are open as PixInsight views; no files were written.");
         return model;
      } finally {
         for (var i = 0; i < owned.length; ++i) {
            var keepWindow = false;
            for (var j = 0; j < keep.length; ++j) keepWindow = keepWindow || owned[i] === keep[j];
            if (!keepWindow && !owned[i].isNull) owned[i].forceClose();
         }
      }
   }

   function chooseInput(caption, initialPath) {
      var d = new OpenFileDialog;
      d.caption = caption;
      d.filters = [["All supported image files", ".fit", ".fits", ".fts", ".xisf"],
                   ["FITS files", ".fit", ".fits", ".fts"],
                   ["PixInsight XISF files", ".xisf"]];
      d.initialPath = initialPath || "";
      d.multipleSelections = false;
      return d.execute() ? d.filePath : "";
   }

   function validView(view) {
      return view !== null && typeof view !== "undefined" && !view.isNull;
   }

   function InputDialog() {
      this.__base__ = Dialog;
      this.__base__();
      var dialog = this;

      this.windowTitle = "astro-lrgb — select inputs";
      this.inputGroup = new GroupBox(this);
      this.inputGroup.title = "Inputs";
      var inputSizer = new VerticalSizer;
      inputSizer.spacing = 5;
      this.inputGroup.sizer = inputSizer;

      this.instructionLabel = new Label(this.inputGroup);
      this.instructionLabel.text = "Choose open views or browse to files; files open as new PixInsight views.\n" +
         "Inputs must be aligned, linear, gradient-corrected, and starless.";
      this.instructionLabel.wordWrapping = true;

      this.lLabel = new Label(this.inputGroup);
      this.lLabel.text = "Luminance input (single-channel)";
      this.lViewList = new ComboBox(this.inputGroup);
      this.lViewList.editEnabled = false;
      this.lViewList.minWidth = 300;
      this.lBrowseButton = new PushButton(this.inputGroup);
      this.lBrowseButton.text = "Browse…";
      this.lSourceLabel = new Label(this.inputGroup);
      this.lSourceLabel.text = "Select an existing view or browse for a file.";
      this.lSourceLabel.wordWrapping = true;

      this.rgbLabel = new Label(this.inputGroup);
      this.rgbLabel.text = "RGB input (three-channel)";
      this.rgbViewList = new ComboBox(this.inputGroup);
      this.rgbViewList.editEnabled = false;
      this.rgbViewList.minWidth = 300;
      this.rgbBrowseButton = new PushButton(this.inputGroup);
      this.rgbBrowseButton.text = "Browse…";
      this.rgbSourceLabel = new Label(this.inputGroup);
      this.rgbSourceLabel.text = "Select an existing view or browse for a file.";
      this.rgbSourceLabel.wordWrapping = true;

      this.alphaControl = new NumericControl(this);
      this.alphaControl.real = true;
      this.alphaControl.label.text = "Matched L contribution:";
      this.alphaControl.setRange(0, 1);
      this.alphaControl.slider.setRange(0, 100);
      this.alphaControl.setPrecision(2);
      this.alphaControl.setValue(DEFAULT_ALPHA);
      this.alphaControl.toolTip = "0 keeps RGB unchanged; 1 uses matched L as the target luminance. Default: 0.65.";

      this.referenceLabel = new Label(this.inputGroup);
      this.referenceLabel.text = "RGB reference";
      this.referenceList = new ComboBox(this.inputGroup);
      this.referenceList.editEnabled = false;
      this.referenceList.addItem("D65 CIE Y (default)");
      this.referenceList.addItem("Filter/QE projection from SPCC + SPFC history (experimental)");
      this.referenceList.currentItem = 0;
      this.referenceList.toolTip = "Experimental mode reads RGB SPCC and L SPFC curves, then adjusts for recorded SPCC channel gains.";
      this.spccFactorLabel = new Label(this.inputGroup);
      this.spccFactorLabel.text = "Recorded RGB SPCC gains (R/G/B): select an RGB view.";
      this.spccFactorLabel.wordWrapping = true;
      this.spccFactorLabel.toolTip = "Read-only XISF image property. The experimental reference divides its filter-response weights by these assumed channel multipliers; D65 does not use them.";

      function viewForSelection(list, index) {
         if (index <= 0) return null;
         var view = View.viewById(list.itemText(index));
         return validView(view) ? view : null;
      }
      function populateViewList(list, preferredView) {
         list.clear();
         list.addItem("<Select an open image view>");
         var windows = ImageWindow.windows;
         var preferredId = validView(preferredView) ? preferredView.id : "";
         var selection = 0;
         for (var i = 0; i < windows.length; ++i) {
            var view = windows[i].mainView;
            list.addItem(view.id);
            if (view.id === preferredId) selection = i + 1;
         }
         list.currentItem = selection;
      }
      function refreshSpccFactors() {
         var view = viewForSelection(dialog.rgbViewList, dialog.rgbViewList.currentItem);
         if (!view) {
            dialog.spccFactorLabel.text = "Recorded RGB SPCC gains (R/G/B): select an RGB view.";
            return;
         }
         try {
            dialog.spccFactorLabel.text = "Recorded RGB SPCC gains (R/G/B): " +
               spccGains(view).map(function (value) { return value.toPrecision(8); }).join(" / ") +
               " (used in experimental mode)";
         } catch (e) {
            dialog.spccFactorLabel.text = "Recorded RGB SPCC gains (R/G/B): unavailable for " + view.id +
               " (experimental mode requires them).";
         }
      }
      this.lViewList.onItemSelected = function(index) {
         var view = viewForSelection(dialog.lViewList, index);
         if (validView(view))
            dialog.lSourceLabel.text = "PixInsight view: " + view.id;
         else
            dialog.lSourceLabel.text = "Select an existing view or browse for a file.";
      };
      this.rgbViewList.onItemSelected = function(index) {
         var view = viewForSelection(dialog.rgbViewList, index);
         if (validView(view))
            dialog.rgbSourceLabel.text = "PixInsight view: " + view.id;
         else
            dialog.rgbSourceLabel.text = "Select an existing view or browse for a file.";
         refreshSpccFactors();
      };
      populateViewList(this.lViewList, null);
      populateViewList(this.rgbViewList, null);
      refreshSpccFactors();

      this.lBrowseButton.onClick = function() {
         var path = chooseInput("Select registered, linear, starless luminance (L)", "");
         if (!path) return;
         try {
            var w = openCopy(path, "astro_lrgb_L");
            populateViewList(dialog.lViewList, w.mainView);
            dialog.lSourceLabel.text = "File: " + File.extractName(path) + " → view " + w.mainView.id;
         } catch (e) {
            new MessageBox(String(e), "Could not open L input", StdIcon_Error, StdButton_Ok).execute();
         }
      };
      this.rgbBrowseButton.onClick = function() {
         var path = chooseInput("Select matching registered, linear, starless RGB", "");
         if (!path) return;
         try {
            var w = openCopy(path, "astro_lrgb_RGB");
            populateViewList(dialog.rgbViewList, w.mainView);
            dialog.rgbSourceLabel.text = "File: " + File.extractName(path) + " → view " + w.mainView.id;
            refreshSpccFactors();
         } catch (e) {
            new MessageBox(String(e), "Could not open RGB input", StdIcon_Error, StdButton_Ok).execute();
         }
      };

      this.runButton = new PushButton(this);
      this.runButton.text = "Run";
      this.runButton.defaultButton = true;
      this.runButton.onClick = function() {
         if (!validView(viewForSelection(dialog.lViewList, dialog.lViewList.currentItem))) {
            new MessageBox("Select an L view or browse to an L file first.", "Missing input",
                           StdIcon_Warning, StdButton_Ok).execute();
            return;
         }
         if (!validView(viewForSelection(dialog.rgbViewList, dialog.rgbViewList.currentItem))) {
            new MessageBox("Select an RGB view or browse to an RGB file first.", "Missing input",
                           StdIcon_Warning, StdButton_Ok).execute();
            return;
         }
         dialog.ok();
      };
      this.cancelButton = new PushButton(this);
      this.cancelButton.text = "Cancel";
      this.cancelButton.onClick = function() { dialog.cancel(); };

      var lSelectSizer = new HorizontalSizer;
      lSelectSizer.spacing = 6;
      lSelectSizer.add(this.lViewList, 100);
      lSelectSizer.add(this.lBrowseButton);
      var rgbSelectSizer = new HorizontalSizer;
      rgbSelectSizer.spacing = 6;
      rgbSelectSizer.add(this.rgbViewList, 100);
      rgbSelectSizer.add(this.rgbBrowseButton);
      inputSizer.add(this.instructionLabel);
      inputSizer.addSpacing(5);
      inputSizer.add(this.lLabel);
      inputSizer.add(lSelectSizer);
      inputSizer.add(this.lSourceLabel);
      inputSizer.addSpacing(8);
      inputSizer.add(this.rgbLabel);
      inputSizer.add(rgbSelectSizer);
      inputSizer.add(this.rgbSourceLabel);
      inputSizer.addSpacing(8);
      inputSizer.add(this.referenceLabel);
      inputSizer.add(this.referenceList);
      inputSizer.add(this.spccFactorLabel);
      inputSizer.addSpacing(8);
      inputSizer.add(this.alphaControl);

      var buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;
      buttonSizer.addStretch();
      buttonSizer.add(this.runButton);
      buttonSizer.add(this.cancelButton);

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add(this.inputGroup);
      this.sizer.add(buttonSizer);
      this.adjustToContents();
      this.setFixedSize();
   }
   InputDialog.prototype = new Dialog;

   function runDialog() {
      var dialog = new InputDialog;
      if (!dialog.execute()) return null;
      var lView = View.viewById(dialog.lViewList.itemText(dialog.lViewList.currentItem));
      var rgbView = View.viewById(dialog.rgbViewList.itemText(dialog.rgbViewList.currentItem));
      return run({lView:lView, rgbView:rgbView, alpha:dialog.alphaControl.value,
                  referenceMode:dialog.referenceList.currentItem === 1 ? "SPCC" : "D65"});
   }

   return {run:run, runDialog:runDialog, fitImagePair:fitImagePair,
           deriveSpccWeights:deriveSpccWeights};
})();

/* Internal entry point used by the script and by a small validation harness. */
if (typeof ASTRO_LRGB_NO_AUTORUN === "undefined" || !ASTRO_LRGB_NO_AUTORUN) {
   try {
      AstroLRGB.runDialog();
   } catch (e) {
      console.criticalln("astro-lrgb failed: " + e);
      if (e.stack) console.criticalln(e.stack);
      new MessageBox(String(e), "astro-lrgb error", StdIcon_Error, StdButton_Ok).execute();
   }
}
